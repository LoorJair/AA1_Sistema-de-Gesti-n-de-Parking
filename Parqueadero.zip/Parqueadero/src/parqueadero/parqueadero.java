package parqueadero;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.*;
import javax.swing.*;
/**
 *
 * @author jair
 */
public class parqueadero extends conexion_mysql{
      private conexion_mysql conexionDB;
    
    
    
public ArrayList<vehiculo> vehiculos; 
  // Tarifa por hora para carros 
public double tarifaCarro = 2.0; 
  // Tarifa por hora para motos
public double tarifaMoto = 1.0;
    // Constructor
    public parqueadero() {
        this.vehiculos = new ArrayList<>();
    }
    // Método para registrar un vehículo
public void registrarVehiculo(String placa, String tipo, String propietario, Double tarifa, Date  horaingreso) {
    // Consulta SQL para insertar el vehículo en la base de datos
    String sql = "INSERT INTO vehiculos (placa, tipo, propietario, tarifa, hora_ingreso) VALUES (?, ?, ?, ?, ?)";
    try (Connection conn = conexionDB.conexion(); // Obtener la conexión a la base de datos
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        // Establecer los parámetros de la consulta (placa, tipo, propietario, tarifa, hora_ingreso)
        stmt.setString(1, placa);
        stmt.setString(2, tipo);
        stmt.setString(3, propietario);
        stmt.setDouble(4, tarifa);
        stmt.setDate(5, horaingreso); 
        // Ejecutar la consulta para insertar el vehículo en la base de datos
        int filasAfectadas = stmt.executeUpdate();
        // Verificar si la inserción fue exitosa
        if (filasAfectadas > 0) {
            JOptionPane.showMessageDialog(null, "Vehículo registrado con éxito: \n" + placa, "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Error: No se pudo registrar el vehículo.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        // Manejo de errores en caso de excepción
        JOptionPane.showMessageDialog(null, "Ocurrió un error al registrar el vehículo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();  // Imprimir el detalle de la excepción en la consola
    }
}
    // Método para calcular la tarifa según el tipo de vehículo
    public double calcularTarifa(String tipo, int horas) {
        if (tipo.equalsIgnoreCase("Carro")) {
            return tarifaCarro * horas;
        } else if (tipo.equalsIgnoreCase("Moto")) {
            return tarifaMoto * horas;
        }
        JOptionPane.showMessageDialog(null, "Tipo de vehículo no reconocido. Por favor, intente de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
        // Ipor si existe un error en este calculo
        return -1; 
    }
 public void actualizarVehiculo(String placa, String nuevoTipo) {
    // Consulta SQL para actualizar solo el tipo del vehículo basado en la placa
    String sql = "UPDATE vehiculos SET tipo = "+nuevoTipo+" WHERE placa = "+placa+"";
    try (Connection conn = conexionDB.conexion(); 
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        // Establecer los parámetros para la consulta (nuevo tipo y placa)
        stmt.setString(2, nuevoTipo);  // Establecer el nuevo tipo
        stmt.setString(1, placa);  // Establecer la placa del vehículo
        // Ejecutar la actualización
        int filasAfectadas = stmt.executeUpdate();
        if (filasAfectadas > 0) {
            System.out.println("Tipo de vehículo actualizado con éxito.");
        } else {
            System.out.println("No se encontró un vehículo con esa placa.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    // Método  para actualizar tarifas
    public void actualizarTarifa(String tipo, double nuevaTarifa) {
        if (tipo.equalsIgnoreCase("Carro")) {
            tarifaCarro = nuevaTarifa;
            JOptionPane.showMessageDialog(null, "Nueva tarifa para carros: " + tarifaCarro, "Actualización de tarifa", JOptionPane.INFORMATION_MESSAGE);
        } else if (tipo.equalsIgnoreCase("Moto")) {
            tarifaMoto = nuevaTarifa;
            JOptionPane.showMessageDialog(null, "Nueva tarifa para motos: " + tarifaMoto, "Actualización de tarifa", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Error: Tipo de vehículo no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
