package parqueadero;
import javax.swing.JOptionPane;
/**
 *
 * @author jair
 */
public class vehiculo {
public String placa; 
public String tipo; 
public double tarifa; 
    // private porque se usan con getter y setter
    private String propietario; 
    private String horaIngreso;
     // Constructor
    public vehiculo(String placa, String tipo, String propietario, String horaIngreso, double tarifa) {
        this.placa = placa;
        this.tipo = tipo;
        this.propietario = propietario;                 
        this.horaIngreso = horaIngreso;
        this.tarifa = tarifa;
    }
    // Getter y Setter
    public String getPropietario() {
        return propietario;
    }
    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }
    public String getHoraIngreso() {
        return horaIngreso;
    }
    public void setHoraIngreso(String horaIngreso) {
        this.horaIngreso = horaIngreso;
    }
    // Método para mostrar información del vehículo
    @Override
    public String toString() {
        return "Vehiculo{" +
                "placa='" + placa + '\'' +
                ", tipo='" + tipo + '\'' +
                ", propietario='" + propietario + '\'' +
                ", horaIngreso='" + horaIngreso + '\'' +
                ", tarifa=" + tarifa +
                '}';
    }
    // Método para mostrar información 
    public void mostrarInformacion() {
        JOptionPane.showMessageDialog(null, toString(), "Información del Vehículo", JOptionPane.INFORMATION_MESSAGE);
    }
}
