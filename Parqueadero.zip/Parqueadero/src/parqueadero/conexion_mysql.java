package parqueadero;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author jair
 */
public class conexion_mysql {
   private static final String URL = "jdbc:mysql://localhost:3306/parqueadero";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
    // Variable para mantener la conexión
    private static Connection conexion;
    public static Connection conexion() {
        if (conexion == null) {
            try {
                // Cargar el driver de MySQL
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establecer la conexión
                conexion = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Conexión exitosa a la base de datos.");
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        return conexion;
    }
}
